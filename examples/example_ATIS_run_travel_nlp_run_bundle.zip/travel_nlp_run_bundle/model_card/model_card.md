# Model card: TF-IDF + Linear SVM

Generated automatically by the Travel NLP Lab notebook. Values below come from this run only.

## Task
Single-label travel-query intent classification (one intent per query).

## Data
- Source file(s): test_atis.csv, train_atis.csv
- Training rows: 4,623 (22 intents)
- Held-out test rows: 850 (20 intents)
- Exact duplicate text/label rows were removed before splitting; train/test normalised-text overlap was checked.

## Model selection
- Candidates: TF-IDF + Logistic Regression, TF-IDF + Linear SVM, TF-IDF + Multinomial Naive Bayes.
- Method: stratified 5-fold cross-validation on the TRAINING data only; metric = Macro-F1; seed = 42.
- The test set was not used to choose the model. The selected model was fitted on the full training set and evaluated once on the test set.
- Classes excluded from cross-validation selection only (too few training rows): aircraft+flight+flight_no, airfare+flight_time, airline+flight_no, cheapest, ground_service+ground_fare

```
                           Model  CV_Macro_F1  CV_Macro_F1_SD  CV_Accuracy  CV_Accuracy_SD
             TF-IDF + Linear SVM       0.7843          0.0326       0.9708          0.0034
    TF-IDF + Logistic Regression       0.7479          0.0369       0.9359          0.0043
TF-IDF + Multinomial Naive Bayes       0.1781          0.0101       0.8155          0.0022
```

## Held-out test performance (single evaluation)
- Accuracy: 0.9541
- Macro-F1: 0.6828
- Weighted-F1: 0.9502
- Intents present in test but never seen in training: airfare+flight, day_name, flight+airline, flight_no+airline

## Autocomplete (next-word) model
- Word n-gram model with stupid-backoff, built from training queries only; exported as results/next_word_model.json.
- Settings {'max_context': 4, 'min_count': 1, 'alpha': 0.2} chosen on a validation slice of the training data; the test set was not used for tuning.
- Held-out next-word accuracy over 9,770 word positions: top-1 42.2%, top-3 62.2%, top-5 69.9% (word-frequency baseline top-3: 22.0%).
- Fit check: no sign of overfitting; test queries are somewhat harder than training folds (distribution shift), not a model fault.
- Suggestions reflect only the wording of this dataset; unseen words get no suggestion of their own.

## Limitations
- Macro-F1 is lower than accuracy when rare intents are poorly recognised; check per-intent results.
- Intents with very few examples give unstable per-intent metrics.
- Linear-model decision scores are not calibrated probabilities.
- Top terms per intent show feature association with predictions, not causal explanation.
- Results describe this dataset only and may not transfer to other travel domains, languages or phrasing.
- SHA-256 hashes in run_manifest.json show consistency with the manifest, not authorship or scientific validity.
