# Model card: TF-IDF + Logistic Regression

Generated automatically by the Travel NLP Lab notebook. Values below come from this run only.

## Task
Single-label travel-query intent classification (one intent per query).

## Data
- Source file(s): hotel_booking_queries.csv
- Training rows: 165 (8 intents)
- Held-out test rows: 42 (8 intents)
- Exact duplicate text/label rows were removed before splitting; train/test normalised-text overlap was checked.

## Model selection
- Candidates: TF-IDF + Logistic Regression, TF-IDF + Linear SVM, TF-IDF + Multinomial Naive Bayes.
- Method: stratified 5-fold cross-validation on the TRAINING data only; metric = Macro-F1; seed = 42.
- The test set was not used to choose the model. The selected model was fitted on the full training set and evaluated once on the test set.
- Classes excluded from cross-validation selection only (too few training rows): none

```
                           Model  CV_Macro_F1  CV_Macro_F1_SD  CV_Accuracy  CV_Accuracy_SD
    TF-IDF + Logistic Regression       1.0000          0.0000       1.0000          0.0000
             TF-IDF + Linear SVM       1.0000          0.0000       1.0000          0.0000
TF-IDF + Multinomial Naive Bayes       0.9756          0.0299       0.9758          0.0297
```

## Held-out test performance (single evaluation)
- Accuracy: 1.0000
- Macro-F1: 1.0000
- Weighted-F1: 1.0000
- Intents present in test but never seen in training: none

## Autocomplete (next-word) model
- Word n-gram model with stupid-backoff, built from training queries only; exported as results/next_word_model.json.
- Settings {'max_context': 2, 'min_count': 2, 'alpha': 0.4} chosen on a validation slice of the training data; the test set was not used for tuning.
- Held-out next-word accuracy over 421 word positions: top-1 54.6%, top-3 74.1%, top-5 80.5% (word-frequency baseline top-3: 20.2%).
- Fit check: no sign of over- or underfitting, but scores vary between folds (small training set), so treat them as indicative.
- Suggestions reflect only the wording of this dataset; unseen words get no suggestion of their own.

## Limitations
- Macro-F1 is lower than accuracy when rare intents are poorly recognised; check per-intent results.
- Intents with very few examples give unstable per-intent metrics.
- Linear-model decision scores are not calibrated probabilities.
- Top terms per intent show feature association with predictions, not causal explanation.
- Results describe this dataset only and may not transfer to other travel domains, languages or phrasing.
- SHA-256 hashes in run_manifest.json show consistency with the manifest, not authorship or scientific validity.
